<?php
include 'db_controller.php'; // Ensure this file returns a valid $conn object

session_start();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Make sure $conn is defined and initialized in db_controller.php
if (!isset($conn)) {
    $_SESSION['flash_mode'] = "alert-danger";
    $_SESSION['flash'] = "Database connection not initialized!";
    die();
}

// Check connection
if ($conn->connect_error) {
    $_SESSION['flash_mode'] = "alert-danger";
    $_SESSION['flash'] = "Failed to connect to Database: " . $conn->connect_error;
    die();
}

try {
    // Create and select database
    $conn->query("CREATE DATABASE IF NOT EXISTS Alumni");
    $conn->select_db("Alumni");

    // user_table creation
    $conn->query("CREATE TABLE IF NOT EXISTS user_table (
        email VARCHAR(50) NOT NULL PRIMARY KEY,
        first_name VARCHAR(50) NOT NULL,
        last_name VARCHAR(50) NOT NULL,
        dob DATE NULL,
        gender VARCHAR(6) NOT NULL,
        contact_number VARCHAR(15) NULL,
        hometown VARCHAR(50) NOT NULL,
        current_location VARCHAR(50) NULL,
        profile_image VARCHAR(100) NULL,
        job_position VARCHAR(50) NULL,
        qualification VARCHAR(70) NULL,
        year INT(4) NULL,
        university VARCHAR(50) NULL,
        company VARCHAR(50) NULL,
        resume VARCHAR(100) NULL
    )");

    // account_table creation
    $conn->query("CREATE TABLE IF NOT EXISTS account_table (
        email VARCHAR(50) NOT NULL,
        password VARCHAR(255) NOT NULL,
        type VARCHAR(5) NOT NULL,
        status VARCHAR(8) NOT NULL,
        FOREIGN KEY (email) REFERENCES user_table(email) ON DELETE CASCADE ON UPDATE CASCADE
    )");

    // event_table creation
    $conn->query("CREATE TABLE IF NOT EXISTS event_table (
        id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
        title VARCHAR(100) NOT NULL,
        location VARCHAR(50) NOT NULL,
        description VARCHAR(700) NOT NULL,
        event_date DATE NOT NULL,
        photo VARCHAR(100) NULL,
        type VARCHAR(10) NOT NULL
    )");

    // event_registration_table creation
    $conn->query("CREATE TABLE IF NOT EXISTS event_registration_table (
        event_id INT NOT NULL,
        participant_email VARCHAR(50) NOT NULL,
        FOREIGN KEY (event_id) REFERENCES event_table(id) ON DELETE CASCADE ON UPDATE CASCADE
    )");

    // advertisement_table creation
    $conn->query("CREATE TABLE IF NOT EXISTS advertisement_table (
        id INT(4) NOT NULL AUTO_INCREMENT PRIMARY KEY,
        title VARCHAR(100) NOT NULL,
        description VARCHAR(700) NOT NULL,
        date_added DATE NOT NULL,
        button_message VARCHAR(50) NULL,
        button_link VARCHAR(700) NULL,
        photo VARCHAR(100) NULL,
        category VARCHAR(50) NOT NULL,
        status VARCHAR(20) NOT NULL,
        advertiser VARCHAR(50) NOT NULL,
        appliable BOOLEAN,
        date_to_hide TIMESTAMP NULL,
        FOREIGN KEY (advertiser) REFERENCES user_table(email) ON DELETE CASCADE ON UPDATE CASCADE
    )");

    // advertisement_registration_table creation
    $conn->query("CREATE TABLE IF NOT EXISTS advertisement_registration_table (
        advertisement_id INT NOT NULL,
        email VARCHAR(50) NOT NULL,
        first_name VARCHAR(50) NOT NULL,
        last_name VARCHAR(50) NOT NULL,
        dob DATE NULL,
        gender VARCHAR(6) NOT NULL,
        contact_number VARCHAR(15) NULL,
        hometown VARCHAR(50) NOT NULL,
        current_location VARCHAR(50) NULL,
        profile_image VARCHAR(100) NULL,
        job_position VARCHAR(50) NULL,
        qualification VARCHAR(70) NULL,
        year INT(4) NULL,
        university VARCHAR(50) NULL,
        company VARCHAR(50) NULL,
        resume VARCHAR(100) NULL,
        FOREIGN KEY (advertisement_id) REFERENCES advertisement_table(id) ON DELETE CASCADE ON UPDATE CASCADE,
        FOREIGN KEY (email) REFERENCES user_table(email) ON DELETE CASCADE ON UPDATE CASCADE
    )");

    // Populate user_table with dummy data if empty
    if ($conn->query("SELECT COUNT(*) as count FROM user_table")->fetch_assoc()['count'] == 0) {
        $conn->query("INSERT INTO user_table (email, first_name, last_name, dob, gender, hometown)
            VALUES
                ('admin@swin.edu.my', 'Admin', 'User', '2023-10-25', 'Male', 'Kuching'),
                ('user0@test.com', 'Ellen', 'Ripley', '2023-12-25', 'Female', '2_fort'),
                ('pootispow@gmail.com', 'Pootis', 'Pow', '2023-11-25', 'Male', 'Turbine'),
                ('user1@test.com', 'Beatrix', 'Kiddo', '2023-10-25', 'Female', 'Texas'),
                ('user2@test.com', 'John', 'McClane', '2023-09-25', 'Male', 'New Jersey'),
                ('user3@test.com', 'Judge Joe', 'Dredd', '2023-08-25', 'Male', 'Perth'),
                ('user4@test.com', 'Alex', 'Murphy', '2023-07-25', 'Male', 'Brunei'),
                ('user5@test.com', 'Thomas A.', 'Anderson', '2023-06-25', 'Male', 'Singapore'),
                ('user6@test.com', 'James', 'Johnson', '2023-05-25', 'Male', 'Johor'),
                ('user7@test.com', 'Cordell', 'Walker', '2023-04-25', 'Male', 'Kota Kinabalu'),
                ('user8@test.com', 'B. A.', 'Baracus', '2023-03-25', 'Male', 'Kuching'),
                ('user9@test.com', 'Exodia the Forbidden', 'One', '2023-02-25', 'Male', 'Perlis'),
                ('user10@test.com', 'John James', 'Rambo', '2023-01-25', 'Male', 'Miri')");
    }

    // Populate account_table with dummy data if empty
    $hashedDefaultUserPassword = password_hash("user", PASSWORD_BCRYPT);
    $hashedDefaultAdminPassword = password_hash("admin", PASSWORD_BCRYPT);
    if ($conn->query("SELECT COUNT(*) as count FROM account_table")->fetch_assoc()['count'] == 0) {
        $conn->query("INSERT INTO account_table (email, password, type, status)
            VALUES
                ('admin@swin.edu.my', '$hashedDefaultAdminPassword', 'admin', 'active'),
                ('user0@test.com', '$hashedDefaultUserPassword', 'user', 'active'),
                ('user1@test.com', '$hashedDefaultUserPassword', 'user', 'active'),
                ('user2@test.com', '$hashedDefaultUserPassword', 'user', 'active'),
                ('user3@test.com', '$hashedDefaultUserPassword', 'user', 'active'),
                ('user4@test.com', '$hashedDefaultUserPassword', 'user', 'active'),
                ('user5@test.com', '$hashedDefaultUserPassword', 'user', 'active'),
                ('user6@test.com', '$hashedDefaultUserPassword', 'user', 'active'),
                ('user7@test.com', '$hashedDefaultUserPassword', 'user', 'active'),
                ('user8@test.com', '$hashedDefaultUserPassword', 'user', 'active'),
                ('user9@test.com', '$hashedDefaultUserPassword', 'user', 'active'),
                ('user10@test.com', '$hashedDefaultUserPassword', 'user', 'active')");
    }

    // Success message
    $_SESSION['flash_mode'] = "alert-success";
    $_SESSION['flash'] = "Database initialized successfully!";
} catch (Exception $e) {
    $_SESSION['flash_mode'] = "alert-danger";
    $_SESSION['flash'] = "An error occurred: " . $e->getMessage();
}

$conn->close();
?>
