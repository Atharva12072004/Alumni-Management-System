<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ACPCE ALUMNI</title>

    <link rel="stylesheet" href="css/styles.css">

    <!-- Bootstrap CSS --><link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <!-- Bootstrap Icons --><link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
     <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    
    <style>
        .scrolling-wrapper {
            display: flex;
            overflow-x: auto; /* Allows horizontal scrolling */
            scroll-behavior: smooth; /* Adds smooth scrolling */
            width: 100%;
            position: relative;
            padding-bottom: 20px; /* Add padding to create space between scrollbar and below cards */
        }

        /* Scrollable item */
        .scrolling-wrapper .scroll-item {
            min-width: 400px; /* Size of each image */
            display: inline-block;
            flex-shrink: 0; /* Prevent shrinking */
            margin: 0 5px;
        }

        .card-img-top {
            width: 100%;
            height: auto;
            object-fit: cover;
        }

        .card {
            width: 23rem;
            border: none;
            box-shadow: 0 4px 4px rgba(0,0,0,.2);
        }
        #abc{
            width: 250px;
            margin-left:50px;
        }
        .logo{
            width: 150px;
        }
        .card-btn {
            border-top-left-radius: 0;
            border-top-right-radius: 0;
        }

        footer h5,footer a {
    font-weight: bold;
    margin-bottom: 1rem;
    text-decoration: none;
    color:white;
}

footer a:hover {
    text-decoration: none;
    cursor: pointer;
}
footer h5:hover{
    color:lightblue;
}
footer i:hover{
    color:lightblue;
}
footer p {
    font-size: 14px;
    margin-top: 10px;
}

    </style>
</head>
<body>
    <?php
        session_start();

        include 'logged_user.php';
    ?>

     
    <!-- Top nav bar -->
    <nav class="navbar sticky-top navbar-expand-lg mb-5">
        <div class="container">
            
            <a class="navbar-brand mx-0 mb-0 h1" href="main_menu.php"> <img class="logo" src="images/clg logo.png" alt="ACPCE LOGO"> </a>

            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse me-5" id="navbarSupportedContent">
                <ul class="navbar-nav mx-auto">
                    <li class="nav-item mx-1">
                        <a class="nav-link nav-main-active px-5" aria-current="page" href="main_menu.php"><i class="bi bi-house-door-fill nav-bi"></i></a>
                    </li>
                    <li class="nav-item mx-1">
                        <a class="nav-link px-5" href="view_alumni.php"><i class="bi bi-people nav-bi"></i></a>
                    </li>
                    <li class="nav-item mx-1">
                        <a class="nav-link px-5" href="view_events.php"><i class="bi bi-calendar-event nav-bi"></i></a>
                    </li>
                    <li class="nav-item mx-1">
                        <a class="nav-link px-5" href="view_advertisements.php"><i class="bi bi-megaphone nav-bi"></i></a>
                    </li>
                </ul>
            </div>
            <?php include 'nav_user.php' ?>
        </div>
    </nav>

     <!-- Admin Uploaded Gallery -->
    <div class="container slide-left">
        <div class="row justify-content-center">
            <div class="scrolling-wrapper" id="imageScroller">
                <?php
                $imagesFile = 'images.json'; // Path to the JSON file where admin images are stored
                $images = [];
                if (file_exists($imagesFile)) {
                    $images = json_decode(file_get_contents($imagesFile), true);
                }

                if (!empty($images)) {
                    foreach ($images as $image) {
                        echo '<div class="scroll-item">';
                        echo '<div class="card text-center">';
                        echo '<img src="' . htmlspecialchars($image['image_path'], ENT_QUOTES) . '" class="card-img-top" alt="' . htmlspecialchars($image['heading'], ENT_QUOTES) . '">';
                        echo '<div class="card-body">';
                        echo '<h5 class="card-title">' . htmlspecialchars($image['heading'], ENT_QUOTES) . '</h5>';
                        echo '</div>';
                        echo '</div>';
                        echo '</div>';
                    }
                } else {
                    echo '<p>No images uploaded by the admin yet.</p>';
                }
                ?>
            </div>
        </div>
    </div>
    

    <div class="container slide-left">
        <div class="row justify-content-center">

            <!-- Alumni Friends -->
            <div class="col-auto mb-5 mx-auto">
                <div class="card text-center">
                    <img src="images/social.png" class="card-img-top" id="abc" alt="Social Image">
                    <div class="card-body">
                        <h5 class="card-title">Alumni List</h5>
                        <p class="card-text">Expand your network. Connect with your college alumni  </p>
                    </div>
                    <div class="d-grid gap-2"> <a role="button" class="btn card-btn btn-primary fw-medium py-2" href="view_alumni.php">View Alumni List</a> </div>
                </div>
            </div>

            <!-- Events/News -->
            <div class="col-auto mb-5 mx-auto">
                <div class="card text-center">
                    <img src="images/event1.jpg" class="card-img-top" alt="Social Event">
                    <div class="card-body">
                        <h5 class="card-title">Events/News</h5>
                        <p class="card-text">Keep an eye out below for our evolving list of events</p>
                    </div>
                    <div class="d-grid gap-2"> <a role="button" class="btn card-btn btn-primary fw-medium py-2" href="view_events.php">View News/Events</a> </div>
                </div>
            </div>

            <!-- Advertisements -->
            <div class="col-auto mb-5 mx-auto">
                <div class="card text-center">
                    <img src="images/job1.png" class="card-img-top" alt="Advertisement Photo">
                    <div class="card-body">
                        <h5 class="card-title">Job Alerts</h5>
                        <p class="card-text">Access exclusive job listings, workshops, seminars to nurture your professional growth</p>
                    </div>
                    <div class="d-grid gap-2"> <a role="button" class="btn card-btn btn-primary fw-medium py-2" href="view_advertisements.php">View Job Alerts</a> </div>
                </div>
            </div>

            <!-- contact us -->
            <div class="col-auto mb-5 mx-auto">
                <div class="card text-center">
                    <img src="images/contact.jpg" class="card-img-top" alt="Advertisement Photo">
                    <div class="card-body">
                        <h5 class="card-title">Contact Us</h5>
                        <p class="card-text">Contact us on E-mail and feel free to ask your queries and doubts</p>
                    </div>
                    <div class="d-grid gap-2"> <a role="button" class="btn card-btn btn-primary fw-medium py-2" href="contact.php">Contact Us</a> </div>
                </div>
            </div>

            <!-- Update Profile -->
            <div class="col-auto mb-5 mx-auto">
                <div class="card text-center">
                    <img src="images/profile.png" class="card-img-top" id="abc" alt="Profile Picture">
                    <div class="card-body">
                        <h5 class="card-title">Update Your Profile</h5>
                        <p class="card-text">Highlight your latest professional achievements and relevant skills</p>
                    </div>
                    <div class="d-grid gap-2"> <a role="button" class="btn card-btn btn-primary fw-medium py-2" href="<?php echo 'update_profile.php?email='.htmlspecialchars($_SESSION['logged_account']['email'])?>">Update</a> </div>
                </div>
            </div>
            
            <!-- Placeholder cards -->
            <div class="col-auto mb-5 mx-auto">
                <div class="card text-center"></div>
            </div>
            <div class="col-auto mb-5 mx-auto">
                <div class="card text-center"></div>
            </div>

        </div>
    </div>
    
    <!-- Footer Section -->
<footer class="bg-black text-white py-4">
    <div class="container text-center">
        <div class="row">
            <div class="col-md-2">
                <a href="">
                <h5>Campus News</h5>
                </a>
            </div>
            <div class="col-md-2">
                <a href="view_events.php">
                <h5>Upcoming Events</h5>
                </a>
            </div>
            <div class="col-md-2">
                <a href="#">
                <h5>Useful Links</h5>
                </a>
            </div>
            <div class="col-md-2">
                <a href="https://www.acpce.org/career-at-acpce/">
                <h5>Career at ACPCE</h5>
                </a>
            </div>
            <div class="col-md-2">
                <a href="https://www.acpce.org/contact-us/">
                <h5>Contact Us</h5>
                </a>
            </div>
        </div>

        <div class="row mt-4">
            <div class="col-md-12">
                <!-- Social Media Icons -->
                <a href="https://www.instagram.com/acpceofficial?igsh=MWFqdXFwYjQ1YWR3ZQ==" class="text-white mx-2">
                    <i class="bi bi-instagram" style="font-size: 24px;"></i>
                </a>
                <a href="https://www.facebook.com/share/n71iGZ4VRTx1nC5m/" class="text-white mx-2">
                    <i class="bi bi-facebook" style="font-size: 24px;"></i>
                </a>
                <a href="https://www.linkedin.com/school/acpce/" class="text-white mx-2">
                    <i class="bi bi-linkedin" style="font-size: 24px;"></i>
                </a>
                <a href="https://x.com/acpce_org?t=PfKt3J_OIS3j9h1_F_o4ZQ&s=09" class="text-white mx-2">
                <i class="bi bi-twitter" style="font-size: 24px;"></i>
                </a>
            </div>
        </div>

        <div class="row mt-3">
            <div class="col-md-12">
                <p class="mb-0">© 2024 ACPCE ALUMNI ASSOCIATION, All Rights Reserved</p>
            </div>
        </div>
    </div>
</footer>

<!-- Bootstrap Icons and CSS -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">


 <!-- Bootstrap Cards -->
 <div class="container slide-left">
        <div class="row justify-content-center">
            <!-- Add your cards here as per your code above -->
        </div>
    </div>
    
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>

    <!-- JavaScript for Automatic Scrolling -->
    <script>
        const scroller = document.getElementById('imageScroller');
        let scrollInterval=1;

        function startAutoScroll() {
            scrollInterval = setInterval(() => {
                // Scroll by 1 pixel every 10ms (adjust the speed by changing pixel or interval)
                scroller.scrollBy({ left: 10, behavior: 'smooth' });

                // When reaching the end, scroll back to the start
                if (scroller.scrollLeft + scroller.clientWidth >= scroller.scrollWidth) {
                    scroller.scrollTo({ left: 0, behavior: 'smooth' });
                }
            }, 20); // Adjust this number to control the speed of scrolling
        }
        // Start auto-scrolling when the page loads
        window.onload = startAutoScroll;
    </script>
</body>
</html>