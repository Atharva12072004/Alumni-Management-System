<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ACPCE Alumni</title>

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">

    <style>
        body {
            background: linear-gradient(85deg, #a18cd1, #fbc2eb); 
        }

        .mainView {
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
            background: linear-gradient(135deg, #f8ffae, #43c6ac); /* Gradient background for the form box */
            color: #333;
            margin-top: 40px;
        }

        .form-label {
            color: black; /* White text for labels */
        }

        .btn-primary {
            background-color: #007bff;
            border-color: #007bff;
        }

        .social-icons a {
            font-size: 30px;
            color: #fff;
            margin: 0 10px;
        }

        .social-icons a:hover {
            color: #007bff;
        }
    </style>
</head>
<body>
    <div class="container mt-5 mainView">
        <h1 class="text-center mb-4">Contact Us</h1>
        
        <?php
        // Initialize an empty message variable to store success/failure messages
        $message = "";

        // Check if the form is submitted
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            $name = $_POST['name'];
            $email = $_POST['email'];
            $userMessage = $_POST['message'];

            // Validate inputs
            if (!empty($name) && !empty($email) && !empty($userMessage) && filter_var($email, FILTER_VALIDATE_EMAIL)) {
                $to = "atharvaharane1272004@gmail.com"; // Replace with your email
                $subject = "New Contact Us Message from $name";
                $body = "Name: $name\nEmail: $email\n\nMessage:\n$userMessage";
                $headers = "From: $email";

                // Try sending the email
                if (mail($to, $subject, $body, $headers)) {
                    $message = "<div class='alert alert-success'>Your message has been sent successfully!</div>";
                } else {
                    $message = "<div class='alert alert-danger'>Failed to send your message. Please try again later.</div>";
                }
            } else {
                $message = "<div class='alert alert-warning'>Please fill in all fields with a valid email address.</div>";
            }
        }
        ?>

        <!-- Display success/error message -->
        <?= $message ?>

        <!-- Contact Form -->
        <form action="contact.php" method="POST">
            <div class="mb-3">
                <label for="name" class="form-label">Your Name</label>
                <input type="text"  placeholder="Enter Your Name Here...." class="form-control" id="name" name="name" required>
            </div>
            <div class="mb-3">
                <label for="email" class="form-label">Your Email</label>
                <input type="email" placeholder="Enter Your Email ID Here...." class="form-control" id="email" name="email" required>
            </div>
            <div class="mb-3">
                <label for="message" class="form-label">Your Message</label>
                <textarea class="form-control"  placeholder="Enter Your Message Here...." id="message" name="message" rows="4" required></textarea>
            </div>
            <button type="submit" class="btn btn-primary w-100">Send Message</button>
        </form>

        <!-- Social Media Icons -->
        <div class="text-center mt-4">
            <h5>Connect with Us</h5>
            <div class="social-icons">
                <a href="https://www.instagram.com/acpceofficial?igsh=MWFqdXFwYjQ1YWR3ZQ==" target="_blank"><i class="bi bi-instagram"></i></a>
                <a href="https://www.facebook.com/share/n71iGZ4VRTx1nC5m/" target="_blank"><i class="bi bi-facebook"></i></a>
                <a href="https://x.com/acpce_org?t=PfKt3J_OIS3j9h1_F_o4ZQ&s=09" target="_blank"><i class="bi bi-twitter"></i></a>
                <a href="https://www.linkedin.com/school/acpce/" target="_blank"><i class="bi bi-linkedin"></i></a>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
</body>
</html>
