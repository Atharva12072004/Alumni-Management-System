<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ACPCE ALUMNI</title>

    <link rel="stylesheet" href="css/styles.css">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">

    <style>
        body {
            background: linear-gradient(85deg, #a18cd1, #fbc2eb);
        }
        .mainBanner{
            padding-right: calc(var(--bs-gutter-x) * 0);
        }
        .mainImg{
            width: 1000px;
            height: 500px;
            border-radius: 20px;
        }
        .logo{
            margin-left: 70px;
            width: 200px;
            margin-bottom: 40px;
            mix-blend-mode: color-burn;
        }
        h1 {
            margin-top: 0;
        }
        .alert-main{
            bottom: 50px;
        }
        .mainView {
            padding: 40px;
            border-radius: 20px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.5);
            background: linear-gradient(135deg, #f8ffae, #43c6ac);
        }
    </style>
</head>
<body>
    <?php
        include 'init_db.php';

        // Check if session is not already started
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }

        // Handle flash messages
        if (isset($_SESSION['flash_mode'])) {
            $flashMode = $_SESSION['flash_mode'];
            unset($_SESSION['flash_mode']);
        }
    ?>

    <!-- Flash message -->
    <div class="container-fluid">
        <?php if (isset($flashMode)){ ?>
            <div class="row justify-content-center position-absolute offset-1 ps-4 mt-0">
                <div class="col">
                    <div class="alert <?php echo $flashMode; ?> mt-4 py-2 fade-in fade-out-alert row align-items-center alert-main" role="alert">
                        <i class="bi <?php echo ($flashMode == "alert-success" ? "bi-check-circle" : "bi-info-circle"); ?> login-bi col-auto px-0"></i>
                        <div class="col ms-1"><?php echo isset($_SESSION['flash']) ? $_SESSION['flash'] : ''; ?></div>
                    </div>
                </div>
            </div>
        <?php } ?>

        <div class="container mt-5 bg-white mainView">
            <div class="row align-items-center">
                <div class="col ms-4 slide-left">
                    <!-- Heading and text -->
                    <a href="https://www.acpce.org/"><img class="logo" src="images/clg logo.png" alt="ACPCE LOGO"></a>
                    <h1 class="text-center mb-4">A. C. PATIL ALUMNI PORTAL</h1>
                    <p>Stay connected with A. C. Patil College and your fellow alumni. Build strong networks and unlock new opportunities to propel your career forward!</p>
                    
                    <div class="row justify-content-center mt-5">
                        <!-- Login button -->
                        <div class="col-auto">
                            <a role="button" href="login.php" class="btn btn-primary fw-medium px-4 py-2">Login</a>
                        </div>
                        <!-- Register button -->
                        <div class="col-auto">
                            <a role="button" href="registration.php" class="btn btn-outline-primary fw-medium px-4 py-2">Register</a>
                        </div>
                    </div>
                </div>

                <!-- Main banner image -->
                <div class="col-8 mainBanner">
                    <img class="img-fluid mainImg" src="images/alumni.jpg" alt="Main Photo"/>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Boostrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
</body>
</html>
