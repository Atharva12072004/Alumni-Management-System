<?php
    // DB server connection info
    $conn_address = "127.0.0.1";
    $conn_port = 3307;  // Use port 3307 instead of the default 3306
    $conn_username = "root";
    $conn_password = "";
    $db_name = "Alumni"; // Specify the database name

    // Try connecting to the DB server
    $conn = new mysqli($conn_address, $conn_username, $conn_password, $db_name, $conn_port);

    // Check if connection failed and redirect to maintenance if it does
    if ($conn->connect_error) {
        header('Location: maintenance.php');
        die("Connection failed: " . $conn->connect_error);
    }
?>
