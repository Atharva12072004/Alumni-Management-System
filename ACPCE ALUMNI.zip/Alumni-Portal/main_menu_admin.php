<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ACPCE ALUMNI</title>

    <link rel="stylesheet" href="css/styles.css">

    <!-- Bootstrap CSS --><link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <!-- Bootstrap Icons --><link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    
    <style>
        .card {
            width: 23rem;
            border: none;
            box-shadow: 0 4px 4px rgba(0,0,0,.2);
        }
        .logo{
            width: 150px;
        }
        .card-btn {
            border-top-left-radius: 0;
            border-top-right-radius: 0;
        }
        footer h5,footer a {
    font-weight: bold;
    margin-bottom: 1rem;
    text-decoration: none;
    color:white;
}

footer a:hover {
    text-decoration: none;
    cursor: pointer;
}
footer h5:hover{
    color:lightblue;
}
footer i:hover{
    color:lightblue;
}
footer p {
    font-size: 14px;
    margin-top: 10px;
}
    </style>
</head>
<body class="admin-bg">
    <?php
        session_start();

        include 'logged_admin.php';
    ?>

    <!-- Top nav bar -->
    <nav class="navbar sticky-top navbar-expand-lg mb-5" style="background-color: #002c59;">
        <div class="container">
            <a class="navbar-brand mx-0 mb-0 h1 text-light" href="main_menu_admin.php"> <img class="logo" src="images/clg logo.png" alt="ACPCE LOGO"> </a>

            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse me-5" id="navbarSupportedContent">
                <ul class="navbar-nav mx-auto">
                    <li class="nav-item mx-1">
                        <a class="nav-link nav-admin-link nav-main-admin-active px-5" aria-current="page" href="main_menu_admin.php"><i class="bi bi-house-door-fill nav-bi"></i></a>
                    </li>
                    <li class="nav-item mx-1">
                        <a class="nav-link nav-admin-link px-5" href="manage_accounts.php"><i class="bi bi-people nav-bi-admin position-relative">
                            <?php if (isset($pendingCount) && $pendingCount > 0) { ?> <span class="position-absolute top-0 start-100 badge rounded-pill bg-danger fst-normal fw-medium small-badge"><?php echo $pendingCount; ?></span><?php } ?>
                        </i></a>
                    </li>
                    <li class="nav-item mx-1">
                        <a class="nav-link nav-admin-link px-5" href="manage_events.php"><i class="bi bi-calendar-event nav-bi-admin"></i></a>
                    </li>
                    <li class="nav-item mx-1">
                        <a class="nav-link nav-admin-link px-5" href="manage_advertisements.php"><i class="bi bi-megaphone nav-bi-admin"></i></a>
                    </li>
                    <li class="nav-item mx-1">
                    <a class="nav-link px-5" href="gallery.php">
                    <i class="bi bi-folder nav-bi-admin"></i></a>
                    </li>
                </ul>
            </div>
            <?php include 'nav_user.php' ?>
        </div>
    </nav>

    <div class="container slide-left">
        <div class="row justify-content-center">
            
            <!-- Manage Events/News -->
            <div class="col-auto mb-5">
                <div class="card text-center">
                    <img src="images/event.jpg" class="card-img-top" alt="Social Event">
                    <div class="card-body">
                        <h5 class="card-title">Events/News</h5>
                        <p class="card-text">Post and manage events/news to publish the latest updates</p>
                    </div>
                    <div class="d-grid gap-2"> <a role="button" class="btn card-btn btn-primary fw-medium py-2" href="manage_events.php">Manage Events/News</a> </div>
                </div>
            </div>

            <!-- Manage User Accounts -->
            <div class="col-auto mb-5 mx-5">
                <div class="card text-center">
                    <img src="images/account.jpg" class="card-img-top" alt="Social Image">
                    <div class="card-body">
                        <h5 class="card-title">User Accounts</h5>
                        <p class="card-text">Manage user account to bolster security measures</p>
                    </div>
                    <div class="d-grid gap-2"> <a role="button" class="btn card-btn btn-primary fw-medium py-2" href="manage_accounts.php">Manage User Accounts</a> </div>
                </div>
            </div>

            <!-- manage images and gallery of college -->
             <!-- Manage User Accounts -->
            <div class="col-auto mb-5 mx-5">
                <div class="card text-center">
                    <img src="images/gallery.png" class="card-img-top" alt="Social Image">
                    <div class="card-body">
                        <h5 class="card-title">College Gallery</h5>
                        <p class="card-text">Manage College gallery and add images on alumni portal</p>
                    </div>
                    <div class="d-grid gap-2"> <a role="button" class="btn card-btn btn-primary fw-medium py-2" href="gallery.php">Manage College Gallery</a> </div>
                </div>
            </div>

            <!-- Manage Advertisements -->
            <div class="col-auto mb-5">
                <div class="card text-center">
                    <img src="images/job.png" class="card-img-top" alt="Advertisement Photo">
                    <div class="card-body">
                        <h5 class="card-title">Job Alerts</h5>
                        <p class="card-text">Manage exclusive job listings, workshops, seminars to nurture others' professional growth</p>
                    </div>
                    <div class="d-grid gap-2"> <a role="button" class="btn card-btn btn-primary fw-medium py-2" href="manage_advertisements.php">Manage Job Alerts</a> </div>
                </div>
            </div>
        </div>

    </div>
       <!-- Footer Section -->
<footer class="bg-black text-white py-4">
    <div class="container text-center">
        <div class="row">
            <div class="col-md-2">
                <a href="">
                <h5>Campus News</h5>
                </a>
            </div>
            <div class="col-md-2">
                <a href="view_events.php">
                <h5>Upcoming Events</h5>
                </a>
            </div>
            <div class="col-md-2">
                <a href="#">
                <h5>Useful Links</h5>
                </a>
            </div>
            <div class="col-md-2">
                <a href="https://www.acpce.org/career-at-acpce/">
                <h5>Career at ACPCE</h5>
                </a>
            </div>
            <div class="col-md-2">
                <a href="https://www.acpce.org/contact-us/">
                <h5>Contact Us</h5>
                </a>
            </div>
        </div>

        <div class="row mt-4">
            <div class="col-md-12">
                <!-- Social Media Icons -->
                <a href="https://www.instagram.com/acpceofficial?igsh=MWFqdXFwYjQ1YWR3ZQ==" class="text-white mx-2">
                    <i class="bi bi-instagram" style="font-size: 24px;"></i>
                </a>
                <a href="https://www.facebook.com/share/n71iGZ4VRTx1nC5m/" class="text-white mx-2">
                    <i class="bi bi-facebook" style="font-size: 24px;"></i>
                </a>
                <a href="https://www.linkedin.com/school/acpce/" class="text-white mx-2">
                    <i class="bi bi-linkedin" style="font-size: 24px;"></i>
                </a>
                <a href="https://x.com/acpce_org?t=PfKt3J_OIS3j9h1_F_o4ZQ&s=09" class="text-white mx-2">
                <i class="bi bi-twitter" style="font-size: 24px;"></i>
                </a>
            </div>
        </div>

        <div class="row mt-3">
            <div class="col-md-12">
                <p class="mb-0">© 2024 ACPCE ALUMNI ASSOCIATION, All Rights Reserved</p>
            </div>
        </div>
    </div>
</footer>
    
    <!-- Boostrap JS --><script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
</body>
</html>