<?php
// File paths
$imagesFile = 'images.json';
$uploadDir = 'uploads/'; // Ensure this directory exists and is writable

// Handle form submission for image upload
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['image'])) {
    $heading = $_POST['heading'];
    $image = $_FILES['image'];

    // Validate file type
    if ($image['error'] === UPLOAD_ERR_OK) {
        if ($image['type'] === 'image/jpeg') {
            // Create the uploads directory if it doesn't exist
            if (!is_dir($uploadDir)) {
                mkdir($uploadDir, 0777, true);
            }

            // Move the uploaded file to the upload directory
            $imagePath = $uploadDir . basename($image['name']);
            if (move_uploaded_file($image['tmp_name'], $imagePath)) {
                // Read existing images from the JSON file
                $images = [];
                if (file_exists($imagesFile)) {
                    $images = json_decode(file_get_contents($imagesFile), true);
                }

                // Add new image info to the array
                $images[] = ['heading' => $heading, 'image_path' => $imagePath];

                // Write updated images array back to JSON file
                file_put_contents($imagesFile, json_encode($images));
                echo "<p class='text-success'>Image uploaded successfully!</p>";
            } else {
                echo "<p class='text-danger'>Failed to move uploaded file.</p>";
            }
        } else {
            echo "<p class='text-danger'>Only JPEG images are allowed.</p>";
        }
    } else {
        echo "<p class='text-danger'>Error during file upload: " . $image['error'] . "</p>";
    }
}

// Handle the deletion of an image
if (isset($_GET['delete'])) {
    $imageToDelete = $_GET['delete'];

    // Load existing images from the JSON file
    if (file_exists($imagesFile)) {
        $images = json_decode(file_get_contents($imagesFile), true);

        // Filter out the image to be deleted
        foreach ($images as $key => $image) {
            if ($image['image_path'] === $imageToDelete) {
                // Remove the image file from the uploads directory
                if (file_exists($imageToDelete)) {
                    unlink($imageToDelete); // Delete the image file
                }

                // Remove the image entry from the array
                unset($images[$key]);

                // Write the updated images array back to the JSON file
                file_put_contents($imagesFile, json_encode(array_values($images))); // Reindex array
                break;
            }
        }
    }

    // Reload the page after deletion
    header("Location: gallery.php");
    exit();
}

// Load existing images from JSON file
$images = [];
if (file_exists($imagesFile)) {
    $images = json_decode(file_get_contents($imagesFile), true);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ACPCE Alumni</title>
    <link rel="stylesheet" href="css/styles.css"> <!-- Add your CSS file -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    <link rel="stylesheet" href="css/styles.css">
    <style>
        body {
            background: linear-gradient(85deg, #a18cd1, #fbc2eb);
            font-family: Arial, sans-serif;
        }
        .logo{
            width: 150px;
        }
        .container1 {
            background: linear-gradient(135deg, #f8ffae, #43c6ac);
            border-radius: 10px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.2);
            padding: 20px;
            margin-bottom: 20px;
            margin-left: 160px;
            margin-right: 160px;
        }

        .card {
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
<nav class="navbar sticky-top navbar-expand-lg" style="background-color: #002c59;">
        <div class="container">
            <a class="navbar-brand mx-0 mb-0 h1 text-light" href="main_menu_admin.php">
                <img class="logo" src="images/clg logo.png" alt="ACPCE LOGO">
            </a>

            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse me-5" id="navbarSupportedContent">
                <ul class="navbar-nav mx-auto">
                    <li class="nav-item mx-1">
                        <a class="nav-link nav-admin-link px-5" href="main_menu_admin.php">
                            <i class="bi bi-house-door nav-bi-admin"></i>
                        </a>
                    </li>
                    <li class="nav-item mx-1">
                        <a class="nav-link nav-admin-link px-5" href="manage_accounts.php">
                            <i class="bi bi-people nav-bi-admin position-relative">
                                <?php if (isset($pendingCount) && $pendingCount > 0) { ?>
                                    <span class="position-absolute top-0 start-100 badge rounded-pill bg-danger fst-normal fw-medium small-badge"><?php echo $pendingCount; ?></span>
                                <?php } ?>
                            </i>
                        </a>
                    </li>
                    <li class="nav-item mx-1">
                    <a class="nav-link nav-admin-link px-5" aria-current="page" href="manage_events.php"><i class="bi bi-calendar-event nav-bi-admin"></i></a>
                    </li>
                    <li class="nav-item mx-1">
                        <a class="nav-link nav-admin-link px-5" href="manage_advertisements.php">
                            <i class="bi bi-megaphone nav-bi-admin"></i>
                        </a>
                    </li>
                    <li class="nav-item mx-1">
                        <a class="nav-link nav-admin-link nav-main-admin-active px-5" href="gallery.php">
                        <i class="bi bi-folder-fill nav-bi"></i>
                        </a>
                    </li>
                </ul>
            </div>
            <?php include 'nav_user.php' ?>
        </div>
    </nav>
    <div class="container1 mt-5">
        <h2 class="mb-4">Admin Gallery Management</h2>
        
        <!-- Upload Form -->
        <form action="gallery.php" method="post" enctype="multipart/form-data" class="mb-4">
            <div class="form-group mb-3">
                <label for="heading">Image Heading:</label>
                <input type="text" placeholder="Add heading for image here..." id="heading" name="heading" required class="form-control">
            </div>
            <div class="form-group mb-3">
                <label for="image">Select Image (.jpg format only):</label>
                <input type="file" id="image" name="image" accept="image/jpeg" required class="form-control">
            </div>
            <button type="submit" class="btn btn-primary mt-3">Upload</button>
        </form> 

        <!-- Display Uploaded Images -->
        <h3 class="mb-5">Uploaded Images</h3>
        <div class="row">
            <?php foreach ($images as $image): ?>
                <div class="col-md-4 mb-3">
                    <div class="card">
                        <img src="<?php echo htmlspecialchars($image['image_path'], ENT_QUOTES); ?>" class="card-img-top" alt="<?php echo htmlspecialchars($image['heading'], ENT_QUOTES); ?>">
                        <div class="card-body">
                            <h5 class="card-title"><?php echo htmlspecialchars($image['heading'], ENT_QUOTES); ?></h5>
                            <a href="?delete=<?php echo htmlspecialchars($image['image_path'], ENT_QUOTES); ?>" class="btn btn-danger">Delete</a>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
